package de.interaapps.pastefy.model.responses;

public class ActionResponse {
    public boolean success = false;

    public ActionResponse() {
    }

    public ActionResponse(boolean success) {
        this.success = success;
    }
}
