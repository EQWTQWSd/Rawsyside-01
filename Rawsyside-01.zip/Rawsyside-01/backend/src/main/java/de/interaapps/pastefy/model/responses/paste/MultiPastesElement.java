package de.interaapps.pastefy.model.responses.paste;

public class MultiPastesElement {
    public String name;

    public String contents;

    public MultiPastesElement(String name, String contents) {
        this.name = name;
        this.contents = contents;
    }
}
