package de.interaapps.pastefy.model.responses.folder;

import de.interaapps.pastefy.model.responses.ActionResponse;

public class CreateFolderResponse extends ActionResponse {
    public FolderResponse folder;
}
