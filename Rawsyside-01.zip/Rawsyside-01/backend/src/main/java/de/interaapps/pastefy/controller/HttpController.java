package de.interaapps.pastefy.controller;

public class HttpController {
}
