package de.interaapps.pastefy.model.responses.paste;

import de.interaapps.pastefy.model.responses.ActionResponse;

public class CreatePasteResponse extends ActionResponse {
    public PasteResponse paste;
}
