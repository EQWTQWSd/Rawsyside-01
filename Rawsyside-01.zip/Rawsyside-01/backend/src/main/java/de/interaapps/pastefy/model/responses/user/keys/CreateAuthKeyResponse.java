package de.interaapps.pastefy.model.responses.user.keys;

import de.interaapps.pastefy.model.responses.ActionResponse;

public class CreateAuthKeyResponse extends ActionResponse {
    public String key;
}
