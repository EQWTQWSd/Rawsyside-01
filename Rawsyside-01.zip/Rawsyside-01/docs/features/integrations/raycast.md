
![./vscode.png](./raycast1.png)

---

Download it from the [Raycast Store](https://www.raycast.com/interaapps/pastefy)

---

![./vscode.png](./raycast2.png)

![./vscode.png](./raycast3.png)
