# Pastefy Plugin for Visual Studio Code

![./vscode.png](./vscode.png)


Download it from the [VS-Code Marketplace](https://marketplace.visualstudio.com/items?itemName=InteraApps.pastefy)