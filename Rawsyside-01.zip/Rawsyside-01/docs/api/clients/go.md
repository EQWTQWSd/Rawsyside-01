# Pastefy Go API Client

::: warning
This client is not regularly updated. It may not support all features of the Pastefy API.
Pasting, editing, deleting, encryption and decryption are supported by this client.
:::

[Official Go API Client](https://github.com/interaapps/pastefy-go-api)