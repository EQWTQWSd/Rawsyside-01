# Pastefy Java API Client


::: info
We currently have not an ideal situation regarding Java clients for the Pastefy API.
Help us improve this by contributing to one of the existing clients or creating a new one.
:::

## Official but outdated
- [Official Java client for Pastefy API](https://github.com/interaapps/pastefy-java-apiclient)

## Newer but unofficial
::: warning
This is an unofficial client and may not be up-to-date with the latest Pastefy API features.
It also is hosted on a 3rd party maven repository which has no guarantee of uptime.
:::
- [Unofficial Java client for Pastefy API by GreenSurvivors](https://github.com/GreenSurvivors/PastefyAPI)