import PrimeUI from 'tailwindcss-primeui';

export default {
  plugins: [ PrimeUI ]
};
