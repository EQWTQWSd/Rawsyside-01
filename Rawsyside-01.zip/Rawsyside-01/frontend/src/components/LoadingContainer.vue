<script setup lang="ts">
import ProgressSpinner from 'primevue/progressspinner'
</script>
<template>
  <div class="flex items-center justify-center p-3">
    <ProgressSpinner class="w-[3rem]" />
  </div>
</template>
